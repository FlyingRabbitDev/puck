﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
public class Selection : MonoBehaviour {
	private RaycastHit Click;
	private bool isGrabbed;
	private Rigidbody grabbedObject;
	public Image PowerBarBorder;
	public Image PowerBarSlider;
	public Image PowerBarEmpty;
	public float PowerFactor = 2.0f;
	public bool Switch;
	public float PowerForce;
	public int ArrowAngle = 0;
	public GameObject DirArrowRotate;
	public Image LeftArrow;
	public Image RightArrow;
	public Image FireButton;
	public Image CancelButton;
	private GameObject SelectedItem;
	public Slider PowerInteractSlider;
	// Use this for initialization
	void Start () {
		isGrabbed = false;
	}
	
	// Update is called once per frame
	void Update () {
		PowerScript ();
		PowerForce = PowerBarSlider.fillAmount * 1000;
		Ray ray = Camera.main.ScreenPointToRay (Input.mousePosition);
		if (Input.GetMouseButtonDown (0)) {
			if (Physics.Raycast (ray, out Click, Mathf.Infinity)) {
				Debug.Log ("You Hit " + Click.transform.name); //Makes sure Code works 
				Debug.Log ("The Coordinates are " + Click.point.x + Click.point.y + Click.point.z);
			}
			if (Click.transform.name == "Puck") {
				Debug.Log ("This is a game piece");
				isGrabbed = true;
				Click.transform.rotation = 	DirArrowRotate.transform.rotation = Quaternion.Euler (0, 0, 0);
				PowerInteractSlider.value = 1;
				SelectedItem = Click.transform.gameObject;
			}

		}


	}
		
	void PowerScript(){
		if (isGrabbed == true) {
			PowerBarActive ();
			LeftArrow.enabled = RightArrow.enabled = FireButton.enabled = CancelButton.enabled = PowerInteractSlider.enabled = true;
			DirArrowRotate.SetActive (true);
			DirArrowRotate.transform.Rotate (0,0,ArrowAngle);
			SelectedItem.transform.Rotate (0, -ArrowAngle, 0);
		}
		else if (isGrabbed == false)
		{
			PowerBarDisable ();
			LeftArrow.enabled = RightArrow.enabled = FireButton.enabled = CancelButton.enabled = PowerInteractSlider.enabled = false;
			DirArrowRotate.SetActive (false);
		}
}
	void PowerBarActive() {
		PowerBarBorder.enabled = PowerBarEmpty.enabled = PowerBarSlider.enabled = true;
		PowerBarSlider.fillAmount = PowerInteractSlider.value;
	}
	void PowerBarDisable(){
		PowerBarBorder.enabled = PowerBarEmpty.enabled = PowerBarSlider.enabled = false;
	/*	if (PowerBarSlider.fillAmount == 1) {
			Switch = true;
		} else if (PowerBarSlider.fillAmount == 0) {
			Switch = false;
		}
		if (Switch == true) {
			PowerBarSlider.fillAmount -= 1.0f / PowerFactor * Time.deltaTime;
		} else if (Switch == false) {
			PowerBarSlider.fillAmount += 1.0f / PowerFactor * Time.deltaTime;
		}
		*/
	}
	public void LeftArrowPress(int onPress){

		if (onPress == 1) {
			ArrowAngle = 2;
		}
		if (onPress == 2) {
			ArrowAngle = -2;
		}

		if (onPress == 0) {
			ArrowAngle = 0;
		}
	}
	public void FireButtonPress (bool isPressed){
		if (isGrabbed == true && isPressed == true) {
			SelectedItem.GetComponent<Rigidbody> ().AddForce (SelectedItem.transform.forward * PowerForce);
			isGrabbed = false;
			SelectedItem.GetComponent<Rigidbody> ().AddForce (Vector3.zero);
		} else if (isPressed == false) {
			isGrabbed = false;
		}
	}
	public void CancelButtonPress(bool isPressed){
		if (isPressed == true) {
			isGrabbed = false;
		}
	}
}
