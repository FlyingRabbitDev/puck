﻿using UnityEngine;
using System.Collections;

public class ForceTest : MonoBehaviour {
	
	public Rigidbody Thing;
	public float Speed = 0.0f;

	// Use this for initialization
	void Start () {
		Thing.GetComponent<Rigidbody> ();
	}

	// Update is called once per frame
	void Update () {
		if(Input.GetMouseButtonDown(0)){
			Thing.AddForce (Input.mousePosition * Speed);
			}
		else {
			Thing.AddForce(0,0,0);
			}
		}
	}

