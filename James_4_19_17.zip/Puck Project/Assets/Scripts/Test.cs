﻿using UnityEngine;
using System.Collections;

public class Test : MonoBehaviour {
	public Camera RedPlayerCamera;
	public Camera BluePlayerCamera;
	public void RedCameraEnable() {
		RedPlayerCamera.enabled = true;
		BluePlayerCamera.enabled = false;
	}
	public void BlueCameraEnable(){
		RedPlayerCamera.enabled = false;
		BluePlayerCamera.enabled = true;
	}
	private int CameraSwitchCount = 0;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

		if (CameraSwitchCount == 0)
			RedCameraEnable ();
		else if (CameraSwitchCount > 2)
			CameraSwitchCount = 0;
		else
			BlueCameraEnable ();
		if (Input.GetKeyUp (KeyCode.Period))
			CameraSwitchCount++;
	}
}
