﻿using UnityEngine;
using System.Collections;

public class PlayerCamera : MonoBehaviour {
	public GameObject BlueCam;
	public GameObject RedCam;
	public int CamSwitch = 0;
	public void BlueCamSwitch() {
		BlueCam.SetActive(true);
		RedCam.SetActive (false);
	}
	public void RedCamSwitch() {
		BlueCam.SetActive(false);
		RedCam.SetActive (true);
	}
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyUp ("v"))
			CamSwitch++;
		if (CamSwitch == 0)
			RedCamSwitch ();
		else if (CamSwitch == 1)
			BlueCamSwitch ();
		else if (CamSwitch == 2)
			CamSwitch = 0;
	}
}
