﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
public class PowerScript : MonoBehaviour {
	public Image Power;
	public float PowerFactor = 2.0f;
	private bool Switch;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (Power.fillAmount == 1) {
			Switch = true;
		}
		else if (Power.fillAmount == 0) {
			Switch = false;
		}
		if (Switch == true) {
			Power.fillAmount -= 1.0f / PowerFactor * Time.deltaTime;
		}
		else if (Switch == false)
		{
			Power.fillAmount += 1.0f / PowerFactor * Time.deltaTime;
		}
			
	}
}
