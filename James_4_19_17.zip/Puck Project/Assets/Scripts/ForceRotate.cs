﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ForceRotate : MonoBehaviour {
	public int ArrowAngle = 0;
	public GameObject DirArrowRotate;
	public Rigidbody Cube;
	// Use this for initialization
	void Start () {
	}
	public void LeftArrowPress(int onPress){

		if (onPress == 1) {
			ArrowAngle = 2;
		}
		if (onPress == 2) {
			ArrowAngle = -2;
		}

		if (onPress == 0) {
			ArrowAngle = 0;
		}
	}
	// Update is called once per frame
	void Update (){
		DirArrowRotate.transform.Rotate (0,0,ArrowAngle);
		Cube.transform.Rotate (0, -ArrowAngle, 0);

	
	}
}
